<div class="loggedHeader">
    <div class="contain">
        <div class="topHead">
            <div class="logo ease">
                <a href="index.php"><img src="../images/logo2.jpg" alt=""></a>
                
            </div>
            <div class="srchBlk relative">
                <input type="text" name="" class="txtBox" placeholder="Search">
                <span><i class="fi-search"></i></span>
            </div>
            <div class="dashBtn">
                <div id="notiBtn">
                    <a href="notification.php">
                        <i class="fa fa-bell"></i>
                        <span class="notification-indicator red"></span>
                    </a>
                </div>
                <div class="proIco dropDown">
                    <div class="inside dropBtn">
                        <div class="proName semi"><em>Welcom</em> John Wick
                        </div>
                        <div class="ico"><img src="../images/users/4.jpg" alt=""></div>
                    </div>
                    <ul class="proDrop dropCnt">
                        <li class="mobile"><a href="notification.php"><i class="fa fa-bell"></i><span>Notifications</span></a></li>
                        <li><a href="settings.php"><i class="fa fa-gear"></i><span>Settings</span></a></li>
                        <li class="mobile"><a href="inbox.php"><i class="fa fa-envelope"></i><span>Messages</span></a></li>
                        <li><a href=""><i class="fi-power-switch"></i><span>Logout</span></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>