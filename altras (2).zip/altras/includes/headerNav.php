<div class="loggedHeader headerNav">
    <div class="contain">
        <div class="topHead">
            <div class="logo ease">
                <a href="index.php"><img src="../images/logo2.png" alt=""></a>
                
            </div>
            <div class="srchBlk relative">
            <nav class="ease">
            <ul id="nav">
                <li>
                    <a href="index.php">Home</a>
                </li>
                <li>
                    <a href="?">Today's Rate</a>
                </li>
                <li>
                    <a href="?">Upload Document</a>
                </li>
                <li>
                    <a href="?">Our Branches</a>
                </li>
                <li>
                    <a href="?">Delivery Addresses</a>
                </li>
                
            </ul>
        </nav>
            </div>
            <div class="dashBtn">
                <div id="notiBtn">
                    <a href="notification.php">
                        <i class="fa fa-bell"></i>
                        <span class="notification-indicator red"></span>
                    </a>
                </div>
                <div id="msgBtn">
                    <a href="?">
                        <i class="fa fa-envelope"></i>
                        <span class="notification-indicator green"></span>
                    </a>
                </div>
                <div class="proIco dropDown">
                    <div class="inside dropBtn">
                        <div class="proName semi"><em>Welcom</em> John Wick
                        </div>
                        <div class="ico"><img src="../images/users/4.jpg" alt=""></div>
                    </div>
                    <ul class="proDrop dropCnt">
                        <li><a href="?"><i class="fi-users"></i><span>Receivers</span></a></li>
                        <li class="mobile"><a href="notification.php"><i class="fa fa-bell"></i><span>Notifications</span></a></li>
                        <li><a href="settings.php"><i class="fa fa-gears"></i><span>Settings</span></a></li>
                        <li><a href="?"><i class="fa fa-question-circle"></i><span>Help</span></a></li>
                        <li class="mobile"><a href="inbox.php"><i class="fa fa-envelope"></i><span>Messages</span></a></li>
                        <li><a href=""><i class="fi-power-switch"></i><span>Logout</span></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>