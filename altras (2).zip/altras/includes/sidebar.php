<aside id="sidebar">
        <!-- <div class="logo">
            <a href="index.php"><img src="../images/logo.png" alt=""></a>
        </div> -->
        <div class="_toggle" id="_toggle"><span></span></div>
        <div class="inside">
            <ul>
                <li class="">
                    <a href="index.php">
                        <span><i class="fa fa-home"></i></span>
                        <em>Home</em>
                    </a>
                </li>
                <li class="">
                    <a href="todayRate.php">
                        <span><i class="fa fa-calendar"></i></span>
                        <em>Today's Rate</em>
                    </a>
                </li>
                <li class="">
                    <a href="receivers.php">
                        <span><i class="fa fa-users"></i></span>
                        <em>Receivers</em>
                    </a>
                </li>

                <li class="">
                    <a href="inbox.php">
                        <!-- <span class="dot"></span> -->
                        <span><i class="fa fa-envelope"></i></span>
                        <em>Inbox</em>
                    </a>
                </li>
                <li class="">
                    <a href="uploadDocument.php">
                        <span><i class="fa fa-upload"></i></span>
                        <em>Upload Document</em>
                    </a>
                </li>
                <li class="">
                    <a href="ourBranches.php">
                        <span><i class="fa fa-building"></i></span>
                        <em>Our Branches</em>
                    </a>
                </li>
                <li class="">
                    <a href="deliveryAddress.php">
                        <span><i class="fa fa-map-marker"></i></span>
                        <em>Delivery Addresses</em>
                    </a>
                </li>
                <li class="">
                    <a href="help.php">
                        <span><i class="fa fa-question-circle"></i></span>
                        <em>Help</em>
                    </a>
                </li>
                <li class="">
                    <a href="setting.php">
                        <span><i class="fa fa-gears"></i></span>
                        <em>Settings</em>
                    </a>
                </li>
            </ul>
            <!-- <ul>
                <li class="">
                    <a href="help.php">
                        <span><i class="fa fa-question-circle"></i></span>
                        <em>Help</em>
                    </a>
                </li>
                <li class="">
                    <a href="setting.php">
                        <span><i class="fa fa-gears"></i></span>
                        <em>Settings</em>
                    </a>
                </li>
            </ul> -->
        </div>
    </aside>