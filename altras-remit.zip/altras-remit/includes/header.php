
<header class="ease simple">
    <div class="contain">
        <div class="logo ease">
            <a href="index.php"><img src="images/logo2.png" alt=""></a>
            
        </div>
        <div class="toggle"><span></span></div>
        <nav class="ease">
            <ul id="nav">
                <li class="<?php if($page=="index"){echo 'active';} ?>">
                    <a href="index.php">Home</a>
                </li>
                <li class="<?php if($page=="about"){echo 'active';} ?>">
                    <a href="about.php">About Us</a>
                </li>
                <li class="<?php if($page=="contact"){echo 'active';} ?>">
                    <a href="contact.php">Contact Us</a>
                </li>
                <!-- <li class="<?php if($page=="calculate"){echo 'active';} ?>">
                    <a href="calculate.php">Calculate</a>
                </li> -->
                <li class="<?php if($page=="branches"){echo 'active';} ?>">
                    <a href="branches.php">Our Branches</a>
                </li>
                <!-- <li class="<?php if($page=="transfer"){echo 'active';} ?>">
                    <a href="transfer.php">Transfer</a>
                </li> -->
                <!-- <li class="<//?php if($page=="signup"){echo 'active';} ?>">
                    <a href="signup.php">Register</a>
                </li> -->
                <!-- <li class="btnLi">
                    <a href="https://my.altras.co.uk/login">Login</a>
                </li> -->
            </ul>
        </nav>
        
        <div class="clearfix"></div>
    </div>
</header>
<!-- header -->


<div class="upperlay"></div>
<!-- <div id="pageloader">
    <span class="loader"></span>
</div> -->
